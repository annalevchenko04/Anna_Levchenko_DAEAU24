from selenium.webdriver.support.ui import WebDriverWait as WDW
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By


class IncomeStatementsReportPage:
    def __init__(self, driver, delay):
        self.driver = driver
        self.delay = delay

        # existing locators
        self.power_bi_button = "//a[@role='tab' and text()='Power BI']"
        self.revenue_report_header = "//*[@id='layout-container-uidb50d']/div/div/h2/span"

        # new locators
        self.export_menu_button = "//button[@title='Export']"
        self.chart_legend_items = "//div[contains(@class,'legend')]//span[@class='labelText']"

    def open_power_bi_report(self):
        btn = WDW(self.driver, self.delay).until(
            EC.element_to_be_clickable((By.XPATH, self.power_bi_button))
        )
        btn.click()

    def switch_to_report_frame(self):
        iframe = self.driver.find_element(By.ID, "mschart")
        self.driver.switch_to.frame(iframe)

    def get_revenue_report_title(self):
        header = self.driver.find_element(By.XPATH, self.revenue_report_header)
        return header.text

    # new methods

    def is_export_button_present(self):
        """Return True if Export button is visible & enabled."""
        try:
            btn = WDW(self.driver, self.delay).until(
                EC.element_to_be_clickable((By.XPATH, self.export_menu_button))
            )
            return btn.is_displayed()
        except:
            return False

    def get_chart_legend_texts(self):
        """Return a list of visible legend labels."""
        items = WDW(self.driver, self.delay).until(
            EC.visibility_of_all_elements_located((By.XPATH, self.chart_legend_items))
        )
        return [el.text for el in items]
