import pytest


@pytest.mark.ui
def test_revenue_header_title(open_income_statements_report_webpage):
    title = open_income_statements_report_webpage.get_revenue_report_title()
    assert title == 'Earnings Release FY23 Q3', "Revenue chart header did not match expected"



@pytest.mark.ui
def test_export_button_visible(open_income_statements_report_webpage):
    assert open_income_statements_report_webpage.is_export_button_present(), "Export button should be present"


@pytest.mark.ui
def test_chart_legend_contains_revenue(open_income_statements_report_webpage):
    legend_items = open_income_statements_report_webpage.get_chart_legend_texts()
    assert any("Revenue" in item for item in legend_items), \
        f"Expected 'Revenue' in legend items, got {legend_items}"
